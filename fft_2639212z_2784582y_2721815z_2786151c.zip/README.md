# Digital Signal Process Assignment 1

There is assignment 1 of DSP from University of Glasgow Postgraduates.

## Assignment Requirement

To improve voice quality and detect voice through using Fourier Transform and analysising the spectrum of audio.

## Directory Structure

- data: Storing pending data
- res: Store analysis results, like figures